var statusResponse = context.getVariable("res.status");
var errorMsg = context.getVariable("res.faultMessage");
var apiNo = context.getVariable('apiNo');

if(statusResponse == "Success")
     context.setVariable("Status","Success");
else 
{
    if(errorMsg.toUpperCase().includes("PLEASE ENTER 10 DIGITS MSISDN")) {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input");
        context.setVariable("httpError", "400");
    }
    else if(errorMsg.toUpperCase().includes("ARGUMNET FOR DAY OR CATEGORY MISMATCH")) {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "400."+apiNo+".101");
        context.setVariable("errorDesc", "Bad Request");
        context.setVariable("errorMessage", "Invalid Input");
        context.setVariable("httpError", "400");
    }
    else {
        context.setVariable("exceptionName", "exceptionName");
        context.setVariable("errorCode", "500."+apiNo+".100");
        context.setVariable("errorDesc", "Internal Server Error");
        context.setVariable("errorMessage", errorMsg);
        context.setVariable("httpError", "500");
    }
}
    
//Please Enter 10 Digits MSISDN


/*if (errorMsg !== null) {
	if (errorMsg.toUpperCase().includes("REQUESTED BILL NOT FOUND")) {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("httpError", "500");
		context.setVariable("errorCode", "500."+apiNo+".101");
		context.setVariable("errorDesc", "Requested bill not found");
		context.setVariable("errorMessage", errorMsg);
	} else if (errorMsg.toUpperCase().includes("CONNECTION REFUSED")) {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("httpError", "500");
		context.setVariable("errorCode", "500."+apiNo+".102");
		context.setVariable("errorDesc", "Connection Refused");
		context.setVariable("errorMessage", errorMsg);
	} else {
		context.setVariable("exceptionName", "exceptionName");
		context.setVariable("httpError", "500");
		context.setVariable("errorCode", "500."+apiNo+".100");
		context.setVariable("errorDesc", "Internal Server Error");
		context.setVariable("errorMessage", errorMsg);
	}
}*/