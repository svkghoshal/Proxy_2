var grant_type = context.getVariable("req.grant_type");
var client_id=context.getVariable("req.client_id");
var client_secret=context.getVariable("req.client_secret");
var scope = context.getVariable("req.scope");
context.setVariable("grant_type",grant_type);
context.setVariable("client_id",client_id);
context.setVariable("client_secret",client_secret);

if (isEmpty(grant_type) || isEmpty(client_id) ||isEmpty(client_secret)){
    context.setVariable("exceptionName","exceptionName");
    context.setVariable("httpError","400");
    context.setVariable("errorCode","400.028.101");
    context.setVariable("errorDesc","Bad Request");
    context.setVariable("errorMessage","Invalid Input");
    throw "serviceException";
}  



function isEmpty(input) {
    return (!input || 0 === input.length);
}
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
