 var myObj=JSON.parse(context.getVariable("request.content"));
 var  i, j ,x="";
 
 for (i in myObj.activations) {
y += myObj.activations[i].user_id;
//var headers = {'Content-Type' : 'application/soap+xml; charset=utf-8'};
var targeturl= "http://10.84.2.50:9001/users/imsi?msisdn=" +y;
var myRequest = new Request(targeturl,"GET");
/*var obj = $.parseXML(myRequest.OLD_MSISDN);*/
print("1x:"+1);
var exchange = httpClient.send(myRequest);
print("1x:"+2);
exchange.waitForComplete(50); //change
print("1x:"+3);
if (exchange.isSuccess()) {
    var responseObj = exchange.getResponse().content.asJSON;
    var imsi= responseObj.imsi;
 myObj.activations[i].imsi+=imsi;
 }
}