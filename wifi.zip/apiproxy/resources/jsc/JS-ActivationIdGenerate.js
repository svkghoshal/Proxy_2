var myObj=JSON.parse(context.getVariable("request.content"));
var  i, j ,s="",x="",y="",z="";

//var r=myObj.activations.length;
for (i in myObj.activations) {
y = myObj.activations[i].user_id;
//var headers = {'Content-Type' : 'application/soap+xml; charset=utf-8'};
var targeturl= "http://10.84.2.50:9001/users/imsi?msisdn=" +y;
var myRequest = new Request(targeturl,"GET");
/*var obj = $.parseXML(myRequest.OLD_MSISDN);*/
print("1x:"+1);
var exchange = httpClient.get(targeturl);
exchange.waitForComplete();
print("1x:"+2);
print("1x:"+3);
if (exchange.isSuccess()) {
    var responseObj = exchange.getResponse().content.asJSON;
    z = myObj.activations[i].imsi;
    newimsi=z.replace(z,responseObj.IMSI);
   /* var imsi= responseObj.imsi;*/
 myObj.activations[i].imsi=newimsi;
 print(myObj.activations[i].imsi);
 print("1x:"+4);
 }  
 else if (exchange.isError()) {
    throw new Error(exchange.getError());
 }

x = myObj.activations[i].activation_id;
s=x.replace(x,(randomString(10, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')+transactionDate()));
myObj.activations[i].activation_id=s;
 print(myObj.activations[i].activation_id);
}

context.setVariable("request.content",JSON.stringify(myObj));

 function randomString(length, chars) {

    var result = '';

    for (var i = length; i > 0; --i)

    result += chars[Math.round(Math.random() * (chars.length - 1))];

    return result;

}

//var res=(randomString(10, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')+transactionDate());

function transactionDate() {

                var now = new Date(),

                pad = function (num) {

                                var norm = Math.abs(Math.floor(num));

                                return (norm < 10 ? '0' : '') + norm;

                };

                return now.getFullYear()

                + pad(now.getMonth() + 1)

                + pad(now.getDate());

 

}