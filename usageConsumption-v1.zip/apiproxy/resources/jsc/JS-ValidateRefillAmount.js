var path = context.getVariable("proxy.pathsuffix");

var refillAmount = context.getVariable("req.refillAmount");
var validateAmount = context.getVariable("req.validateAmount");

var jsonRefillRate = context.getVariable("refillRate");

var partnerCode = "" + context.getVariable("req.channelBankCode");
var pymtChannelCode = "" + context.getVariable("req.channelCode");

var isCacheHit = context.getVariable("lookupcache.LCUserRefillRate.cachehit");

if (!isCacheHit) {
    context.setVariable("validateError", "CacheFailed");
} else {
     if((/^(\/users\/.*\/validate)$/).test(path) || (/^(\/rtr\/.*\/validate)$/).test(path)) {
        refillAmount = validateAmount;
        context.setVariable("req.refillAmount", validateAmount);
    }
    var isValidRate = false;
    
    var refillRateConf = JSON.parse(jsonRefillRate);
    
    for (i = 0; i < refillRateConf.length; i++) {
        if(partnerCode == refillRateConf[i]["PartnerCode"] && pymtChannelCode == refillRateConf[i]["PaymentChannelCode"]) {
            var refillRate = refillRateConf[i]["PaidAmount"];
            var bankCode = refillRateConf[i]["CbsBankCode"];
        }
    }
    
    if(refillRate) {
        refillRate = refillRate.split(',');
        for (i = 0; i < refillRate.length; i++) {
            if (parseFloat(refillRate[i]) == refillAmount) {
                isValidRate = true;
                context.setVariable("cbsBankCode", bankCode);
                break;
            }
        }
        
        if (!isValidRate) {
            context.setVariable("validateError", "InvalidRefillAmount");
        }
    } else {
        context.setVariable("validateError", "CacheFailed");
    }
}