var responseContent = "";

var apiErr = context.getVariable("fault.name");
print("error: " + apiErr);

if(isEmpty(context.getVariable("error.content"))) {
    responseContent = "" + context.getVariable("response.content");
} 
else {
    responseContent = "" + context.getVariable("error.content");
}

context.setVariable("northboundRequestDatetime", "" + context.getVariable("clientStartTime")); //override
context.setVariable("northboundResponseDatetime", "" + context.getVariable("clientEndTime")); //override
context.setVariable("northbound.response", setNorthSouthJsonRequestResponse(responseContent)); 


//---- Set Variable ----
//---- handle error which is occur durring call to target server e.g., service unavailable
if(!isEmpty(apiErr)){
    //--- SB target
    if(!isEmpty(context.getVariable("southbound.target.server")) && isEmpty(context.getVariable("southbound.response"))){
        context.setVariable("southbound.request", apiErr);
    }
    else{
         //--- Service Callout 1
        if(!isEmpty(context.getVariable("southboundSevice1.target.server")) && isEmpty(context.getVariable("southboundSevice1.response"))){
            context.setVariable("southboundSevice1.request", apiErr);
        }
    }
}

//---- Clear Variable -------
if(isEmpty(context.getVariable("southboundSevice1.request"))){
    context.setVariable("southboundService1EndpointUrlDatetime", "");
    context.setVariable("southboundService1RequestDatetime", "");
}

if(isEmpty(context.getVariable("southbound.request"))){
    context.setVariable("southboundEndpointUrlDatetime", "");
    context.setVariable("southboundRequestDatetime", "");
}

//---- Override Target Start Time for wtite log -----
if(!isEmpty(context.getVariable("southboundRequestDatetime"))){
    context.setVariable("targetStartTime", context.getVariable("southboundRequestDatetime"));
    context.setVariable("targetServer", context.getVariable("southbound.target.server"));
}
else{
    
    if(!isEmpty(context.getVariable("southboundService1RequestDatetime"))){
        context.setVariable("targetStartTime", context.getVariable("southboundService1RequestDatetime"));
        context.setVariable("targetServer", context.getVariable("southboundSevice1.target.server"));
    }
}


//---- Override Target End Time for wtite log -----
if(!isEmpty(context.getVariable("southboundService1ResponseDatetime"))){
    context.setVariable("targetEndTime", context.getVariable("southboundService1ResponseDatetime"));
}
else{
    
    if(!isEmpty(context.getVariable("southboundResponseDatetime"))){
        context.setVariable("targetEndTime", context.getVariable("southboundResponseDatetime"));
    }
}


