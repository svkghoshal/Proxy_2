var faultName = context.getVariable("fault.name");
var validateError = context.getVariable("validateError");
var path = context.getVariable("proxy.pathsuffix");
var verb = context.getVariable("request.verb");

print("faultName = " + faultName);

if(!isEmpty(validateError)) {
    faultName = validateError;
    print("override faultName = " + faultName);
}
try {
    switch(verb) {
        case "GET":
            if ((/^(\/users\/.*\/validate)$/).test(path)) {
                switch(faultName) {
                        case "MissingCustomAttributes":
                            setResponse("400", "400.062.0000", "Bad Request", "Missing custom attributes");
                            break;
                            
                        case "IPDeniedAccess":
                            setResponse("403", "403.062.0001", "Forbidden", "IP address is denied to access");
                            break;
                            
                        case "SpikeArrestViolation":
                            setResponse("429", "429.062.2001", "Too Many Requests", "Spike arrest violation");
                            break;
                        case "QuotaViolation":
                            setResponse("429", "429.062.2002", "Too Many Requests", "Quota limit exceeded");
                            break;
                        case "ConcurrentRatelimtViolation":
                            setResponse("429", "429.062.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                            break;

                        case "ScriptExecutionFailed":
                        case "ScriptExecutionFailedLineNumber":
                        case "ScriptSecurityError":
                            setResponse("500", "500.062.2004", "Internal Server Error", "JavaScript runtime error");
                            break;

                        case "access_token_expired":
                        case "invalid_access_token":
                        case "InvalidAccessToken":
                            setResponse("500", "500.062.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                            break;

                        case "BusinessValidationFailed":
                            setResponse("500", "500.062.2006", "Internal Server Error", "Request input is malformed or invalid");
                            break;
                        
                        case "InvalidRefillAmount":
                            setResponse("400", "400.062.0001", "Bad Request",  "Invalid refill amount rate");
                            break;
                        
                        case "CacheFailed":
                            setResponse("404", "404.062.0001", "Resource not found", "Resource not found/Invalid resource");
                            break;

                        case "JSONPathCompilationFailed":
                        case "InvalidJSONPath":
                        case "JsonPathParsingFailure":
                            setResponse("500", "500.062.2007", "Internal Server Error", "Invalid JSON path.");
                            break;

                        default:
                            setResponse("500", "500.062.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                            break;
                }
            } else if((/^(\/rtr\/.*\/validate)$/).test(path)) {
                switch(faultName) {
                    case "MissingCustomAttributes":
                        setResponse("400", "400.064.0000", "Bad Request", "Missing custom attributes");
                        break;
                        
                    case "IPDeniedAccess":
                        setResponse("403", "403.064.0001", "Forbidden", "IP address is denied to access");
                        break;
                        
                    case "SpikeArrestViolation":
                        setResponse("429", "429.064.2001", "Too Many Requests", "Spike arrest violation");
                        break;
                    case "QuotaViolation":
                        setResponse("429", "429.064.2002", "Too Many Requests", "Quota limit exceeded");
                        break;
                    case "ConcurrentRatelimtViolation":
                        setResponse("429", "429.064.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                        break;

                    case "ScriptExecutionFailed":
                    case "ScriptExecutionFailedLineNumber":
                    case "ScriptSecurityError":
                        setResponse("500", "500.064.2004", "Internal Server Error", "JavaScript runtime error");
                        break;

                    case "access_token_expired":
                    case "invalid_access_token":
                    case "InvalidAccessToken":
                        setResponse("500", "500.064.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                        break;

                    case "BusinessValidationFailed":
                        setResponse("500", "500.064.2006", "Internal Server Error", "Request input is malformed or invalid");
                        break;
                    
                    case "CacheFailed":
                        setResponse("404", "404.064.0001", "Resource not found", "Resource not found/Invalid resource");
                        break;

                    case "JSONPathCompilationFailed":
                    case "InvalidJSONPath":
                    case "JsonPathParsingFailure":
                        setResponse("500", "500.064.2007", "Internal Server Error", "Invalid JSON path.");
                        break;

                    case "InvalidRefillAmount":
                        setResponse("400", "400.064.0005", "Bad Request", "Invalid refill amount");
                        break;

                    default:
                        setResponse("500", "500.064.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                        break;
                }
            } else if((/^(\/rtr\/balance)$/).test(path)) {
                switch(faultName) {
                    case "MissingCustomAttributes":
                        setResponse("400", "400.067.0000", "Bad Request", "Missing custom attributes");
                        break;
                        
                    case "IPDeniedAccess":
                        setResponse("403", "403.067.0001", "Forbidden", "IP address is denied to access");
                        break;
                        
                    case "SpikeArrestViolation":
                        setResponse("429", "429.067.2001", "Too Many Requests", "Spike arrest violation");
                        break;
                    case "QuotaViolation":
                        setResponse("429", "429.067.2002", "Too Many Requests", "Quota limit exceeded");
                        break;
                    case "ConcurrentRatelimtViolation":
                        setResponse("429", "429.067.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                        break;

                    case "ScriptExecutionFailed":
                    case "ScriptExecutionFailedLineNumber":
                    case "ScriptSecurityError":
                        setResponse("500", "500.067.2004", "Internal Server Error", "JavaScript runtime error");
                        break;

                    case "access_token_expired":
                    case "invalid_access_token":
                    case "InvalidAccessToken":
                        setResponse("500", "500.067.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                        break;

                    case "BusinessValidationFailed":
                        setResponse("500", "500.067.2006", "Internal Server Error", "Request input is malformed or invalid");
                        break;
                    
                    case "CacheFailed":
                        setResponse("404", "404.067.0001", "Resource not found", "Resource not found/Invalid resource");
                        break;

                    case "JSONPathCompilationFailed":
                    case "InvalidJSONPath":
                    case "JsonPathParsingFailure":
                        setResponse("500", "500.067.2007", "Internal Server Error", "Invalid JSON path.");
                        break;

                    case "InvalidRetailerNumber":
                        setResponse("400", "400.067.0015", "Bad Request", "Invalid retailer number");
                        break;

                    default:
                        setResponse("500", "500.067.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                        break;
                }
            } else if((/^(\/usersRTR\/transaction)$/).test(path)) {
                switch(faultName) {
                    case "MissingCustomAttributes":
                        setResponse("400", "400.068.0000", "Bad Request", "Missing custom attributes");
                        break;
                        
                    case "IPDeniedAccess":
                        setResponse("403", "403.068.0001", "Forbidden", "IP address is denied to access");
                        break;
                        
                    case "SpikeArrestViolation":
                        setResponse("429", "429.068.2001", "Too Many Requests", "Spike arrest violation");
                        break;
                    case "QuotaViolation":
                        setResponse("429", "429.068.2002", "Too Many Requests", "Quota limit exceeded");
                        break;
                    case "ConcurrentRatelimtViolation":
                        setResponse("429", "429.068.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                        break;

                    case "ScriptExecutionFailed":
                    case "ScriptExecutionFailedLineNumber":
                    case "ScriptSecurityError":
                        setResponse("500", "500.068.2004", "Internal Server Error", "JavaScript runtime error");
                        break;

                    case "access_token_expired":
                    case "invalid_access_token":
                    case "InvalidAccessToken":
                        setResponse("500", "500.068.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                        break;

                    case "BusinessValidationFailed":
                        setResponse("500", "500.068.2006", "Internal Server Error", "Request input is malformed or invalid");
                        break;
                    
                    case "CacheFailed":
                        setResponse("404", "404.068.0001", "Resource not found", "Resource not found/Invalid resource");
                        break;

                    case "JSONPathCompilationFailed":
                    case "InvalidJSONPath":
                    case "JsonPathParsingFailure":
                        setResponse("500", "500.068.2007", "Internal Server Error", "Invalid JSON path.");
                        break;

                    case "InvalidRetailerNumber":
                        setResponse("400", "400.068.0006", "Bad Request", "Invalid retailer number");
                        break;

                    default:
                        setResponse("500", "500.068.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                        break;
                }
            } else {
                setResponse("404", "404.043.0001", "Resource not found", "Resource not found/Invalid resource");
            }
            break;
        case "POST":
            if ((/^(\/users\/.*\/refill)$/).test(path)) {
                switch(faultName) {
                    case "MissingCustomAttributes":
                        setResponse("400", "400.043.0000", "Bad Request", "Missing custom attributes");
                        break;
                        
                    case "IPDeniedAccess":
                        setResponse("403", "403.043.0001", "Forbidden", "IP address is denied to access");
                        break;
                        
                    case "SpikeArrestViolation":
                        setResponse("429", "429.043.2001", "Too Many Requests", "Spike arrest violation");
                        break;
                    case "QuotaViolation":
                        setResponse("429", "429.043.2002", "Too Many Requests", "Quota limit exceeded");
                        break;
                    case "ConcurrentRatelimtViolation":
                        setResponse("429", "429.043.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                        break;

                    case "ScriptExecutionFailed":
                    case "ScriptExecutionFailedLineNumber":
                    case "ScriptSecurityError":
                        setResponse("500", "500.043.2004", "Internal Server Error", "JavaScript runtime error");
                        break;

                    case "access_token_expired":
                    case "invalid_access_token":
                    case "InvalidAccessToken":
                        setResponse("500", "500.043.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                        break;

                    case "BusinessValidationFailed":
                        setResponse("500", "500.043.2006", "Internal Server Error", "Request input is malformed or invalid");
                        break;
                    
                    case "InvalidRefillAmount":
                        setResponse("400", "400.043.0001", "Bad Request", "Invalid refill amount rate");
                        break;
                    
                    case "CacheFailed":
                        setResponse("404", "404.043.0001", "Resource not found", "Resource not found/Invalid resource");
                        break;

                    case "JSONPathCompilationFailed":
                    case "InvalidJSONPath":
                    case "JsonPathParsingFailure":
                        setResponse("500", "500.043.2007", "Internal Server Error", "Invalid JSON path.");
                        break;

                    default:
                        setResponse("500", "500.043.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                        break;
                }
            } else if ((/^(\/rtr\/.*\/refill)$/).test(path)) {
                switch(faultName) {
                    case "MissingCustomAttributes":
                        setResponse("400", "400.065.0000", "Bad Request", "Missing custom attributes");
                        break;
                        
                    case "IPDeniedAccess":
                        setResponse("403", "403.065.0001", "Forbidden", "IP address is denied to access");
                        break;
                        
                    case "SpikeArrestViolation":
                        setResponse("429", "429.065.2001", "Too Many Requests", "Spike arrest violation");
                        break;
                    case "QuotaViolation":
                        setResponse("429", "429.065.2002", "Too Many Requests", "Quota limit exceeded");
                        break;
                    case "ConcurrentRatelimtViolation":
                        setResponse("429", "429.065.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                        break;

                    case "ScriptExecutionFailed":
                    case "ScriptExecutionFailedLineNumber":
                    case "ScriptSecurityError":
                        setResponse("500", "500.065.2004", "Internal Server Error", "JavaScript runtime error");
                        break;

                    case "access_token_expired":
                    case "invalid_access_token":
                    case "InvalidAccessToken":
                        setResponse("500", "500.065.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                        break;

                    case "BusinessValidationFailed":
                        setResponse("500", "500.065.2006", "Internal Server Error", "Request input is malformed or invalid");
                        break;
                    
                    case "CacheFailed":
                        setResponse("404", "404.065.0001", "Resource not found", "Resource not found/Invalid resource");
                        break;
                    
                    case "InvalidRefillAmount":
                        setResponse("400", "400.065.0024", "Bad Request", "Invalid refill amount");
                        break;

                    case "JSONPathCompilationFailed":
                    case "InvalidJSONPath":
                    case "JsonPathParsingFailure":
                        setResponse("500", "500.065.2007", "Internal Server Error", "Invalid JSON path.");
                        break;

                    default:
                        setResponse("500", "500.065.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                        break;
                }
            } else if ((/^(\/usersRTR\/.*\/refill)$/).test(path)) {
                switch(faultName) {
                    case "MissingCustomAttributes":
                        setResponse("400", "400.006.0000", "Bad Request", "Missing custom attributes");
                        break;
                        
                    case "IPDeniedAccess":
                        setResponse("403", "403.006.0001", "Forbidden", "IP address is denied to access");
                        break;
                        
                    case "SpikeArrestViolation":
                        setResponse("429", "429.006.2001", "Too Many Requests", "Spike arrest violation");
                        break;
                    case "QuotaViolation":
                        setResponse("429", "429.006.2002", "Too Many Requests", "Quota limit exceeded");
                        break;
                    case "ConcurrentRatelimtViolation":
                        setResponse("429", "429.006.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                        break;

                    case "ScriptExecutionFailed":
                    case "ScriptExecutionFailedLineNumber":
                    case "ScriptSecurityError":
                        setResponse("500", "500.006.2004", "Internal Server Error", "JavaScript runtime error");
                        break;

                    case "access_token_expired":
                    case "invalid_access_token":
                    case "InvalidAccessToken":
                        setResponse("500", "500.006.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                        break;

                    case "BusinessValidationFailed":
                        var missParameter = context.getVariable("missParameter");
                        switch(missParameter) {
                            case "customerObject":
                                setResponse("400", "400.006.0014", "Bad Request", "Missing input parameter: customer info");
                                break;
                            case "customerType":
                                setResponse("400", "400.006.0015", "Bad Request", "Missing input parameter: customer info type");
                                break;
                            case "customerValue":
                                setResponse("400", "400.006.0016", "Bad Request", "Missing input parameter: customer info value");
                                break;
                            case "refillObject":
                                setResponse("400", "400.006.0017", "Bad Request", "Missing input parameter: refill info");
                                break;
                            case "refillTxId":
                                setResponse("400", "400.006.0018", "Bad Request", "Missing input parameter: refill info txid");
                                break;
                            case "refillAmount":
                                setResponse("400", "400.006.0019", "Bad Request", "Missing input parameter: refill info amount");
                                break;
                            case "refillStartCallDate":
                                setResponse("400", "400.006.0020", "Bad Request", "Missing input parameter: refill info startCallDate");
                                break;
                            case "partnerObject":
                                setResponse("400", "400.006.0021", "Bad Request", "Missing input parameter: partner profile");
                                break;
                            case "partnerRetailerNumber":
                                setResponse("400", "400.006.0022", "Bad Request", "Missing input parameter: partner profile retailerNumber");
                                break;
                            case "partnerPartnerCode":
                                setResponse("400", "400.006.0025", "Bad Request", "Missing input parameter: partner profile partnerCode");
                                break;
                            case "partnerPinCode":
                                setResponse("400", "400.006.0026", "Bad Request", "Missing input parameter: partner profile pinCode");
                                break;
                            case "partnerRetryFlag":
                                setResponse("400", "400.006.0027", "Bad Request", "Missing input parameter: partner profile retryFlag");
                                break;
                            default:
                                setResponse("500", "500.006.2006", "Internal Server Error", "Request input is malformed or invalid");
                                break;
                        }
                        break;
                    
                    case "CacheFailed":
                        setResponse("404", "404.006.0001", "Resource not found", "Resource not found/Invalid resource");
                        break;
                    
                    case "InvalidRefillAmount":
                        setResponse("400", "400.006.0012", "Bad Request", "Invalid refill amount");
                        break;

                    case "JSONPathCompilationFailed":
                    case "InvalidJSONPath":
                    case "JsonPathParsingFailure":
                        setResponse("500", "500.006.2007", "Internal Server Error", "Invalid JSON path.");
                        break;

                    default:
                        setResponse("500", "500.006.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                        break;
                }
            } else {
                setResponse("404", "404.043.0001", "Resource not found", "Resource not found/Invalid resource");
            }
            break;
        case "DELETE":
            if ((/^(\/rtr\/.*\/reverse)$/).test(path)) {
                switch(faultName) {
                    case "MissingCustomAttributes":
                        setResponse("400", "400.066.0000", "Bad Request", "Missing custom attributes");
                        break;
                        
                    case "IPDeniedAccess":
                        setResponse("403", "403.066.0001", "Forbidden", "IP address is denied to access");
                        break;
                        
                    case "SpikeArrestViolation":
                        setResponse("429", "429.066.2001", "Too Many Requests", "Spike arrest violation");
                        break;
                    case "QuotaViolation":
                        setResponse("429", "429.066.2002", "Too Many Requests", "Quota limit exceeded");
                        break;
                    case "ConcurrentRatelimtViolation":
                        setResponse("429", "429.066.2003", "Too Many Requests", "Concurrent rate limit connection exceeded");
                        break;

                    case "ScriptExecutionFailed":
                    case "ScriptExecutionFailedLineNumber":
                    case "ScriptSecurityError":
                        setResponse("500", "500.066.2004", "Internal Server Error", "JavaScript runtime error");
                        break;

                    case "access_token_expired":
                    case "invalid_access_token":
                    case "InvalidAccessToken":
                        setResponse("500", "500.066.2005", "Internal Server Error", "Invalid ApiKey for given resource");
                        break;

                    case "BusinessValidationFailed":
                        setResponse("500", "500.066.2006", "Internal Server Error", "Request input is malformed or invalid");
                        break;

                    case "JSONPathCompilationFailed":
                    case "InvalidJSONPath":
                    case "JsonPathParsingFailure":
                        setResponse("500", "500.066.2007", "Internal Server Error", "Invalid JSON path.");
                        break;

                    default:
                        setResponse("500", "500.066.2000", "Internal Server Error", "Internal Server Error: {"+faultName+"}");
                        break;
                }
            } else {
                setResponse("404", "404.043.0001", "Resource not found", "Resource not found/Invalid resource");
            }
            break;
        default:
            setResponse("404", "404.043.0001", "Resource not found", "Resource not found/Invalid resource");
            break;
    }
} catch(ex) {
    if ((/^(\/users\/.*\/refill)$/).test(path)) {
        setResponse("500", "500.043.2004", "Internal Server Error", "JavaScript runtime error");
    } else if ((/^(\/users\/.*\/validate)$/).test(path)) {
        setResponse("500", "500.062.2004", "Internal Server Error", "JavaScript runtime error");
    } else if ((/^(\/rtr\/.*\/validate)$/).test(path)) {
        setResponse("500", "500.064.2004", "Internal Server Error", "JavaScript runtime error");
    } else if ((/^(\/rtr\/.*\/refill)$/).test(path)) {
        setResponse("500", "500.065.2004", "Internal Server Error", "JavaScript runtime error");
    } else if ((/^(\/rtr\/.*\/reverse)$/).test(path)) {
        setResponse("500", "500.066.2004", "Internal Server Error", "JavaScript runtime error");
    } else if ((/^(\/rtr\/.*\/balance)$/).test(path)) {
        setResponse("500", "500.067.2004", "Internal Server Error", "JavaScript runtime error");
    } else if ((/^(\/usersRTR\/transaction)$/).test(path)) {
        setResponse("500", "500.068.2004", "Internal Server Error", "JavaScript runtime error");
    } else if ((/^(\/usersRTR\/.*\/refill)$/).test(path)) {
        setResponse("500", "500.006.2004", "Internal Server Error", "JavaScript runtime error");
    } else {
        setResponse("404", "404.043.0001", "Resource not found", "Resource not found/Invalid resource");
    }
}
context.setVariable("resp.responseDttm", getYYYYMMddHHmmssSSSWithSymbolDotUseDate(new Date()));
setReasonPhrase(context.getVariable("resp.httpStatusCode")); 