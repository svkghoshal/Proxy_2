
var access_token = context.getVariable("req.access_token");

context.setVariable("access_token",access_token);


if (isEmpty(access_token)){
    
errorcode="400.028.101";
context.setVariable("errorcode",errorcode);
errormessage="Invalid Input";
context.setVariable("errormessage",errormessage);
throw "serviceException";
}  



function isEmpty(input) {
    return (!input || 0 === input.length);
}
function ISODateString() {
    var now = new Date(),
        tzo = -now.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function(num) {
            var norm = Math.abs(Math.floor(num));
            return (norm < 10 ? '0' : '') + norm;
        };
    return now.getFullYear() 
        + '-' + pad(now.getMonth()+1)
        + '-' + pad(now.getDate())
        + 'T' + pad(now.getHours())
        + ':' + pad(now.getMinutes()) 
        + ':' + pad(now.getSeconds()) 
        + dif + pad(tzo / 60) 
        + ':' + pad(tzo % 60);
}
 