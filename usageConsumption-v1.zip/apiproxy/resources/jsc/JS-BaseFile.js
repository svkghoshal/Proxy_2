function printProxyRequest(data) {
    print("Proxy Request = " + data);
}

function printTargetResponse(data) {
    print("Target Response = " + data);
    print("------------------------------------------------------------------");
}

function isEmpty(data){
    return (data === "" || data === "null" || data === "undefined" || 
            data === null || data === undefined || 0 === data.length);
}

function convertMobileNotoPrefix66(mobileNo){
    if(mobileNo.match("(0)[0-9]{9}")){
        mobileNo = "66" + mobileNo.substring(1, mobileNo.length);
    }
    
    return mobileNo;
}

function getYYYYMMddHHmmssSSSWithoutSymbolUseDate(today) {
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSeconds = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + month + day + hour + minute + second + milliSeconds;
}

function getYYYYMMddHHmmssWithoutSymbolUseDate(today) {
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    
    return year + month + day + hour + minute + second;
}

function getYYYYMMddHHmmssWithoutSymbol() {
    var today = new Date();
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    
    return year + month + day + hour + minute + second;
}

function getTimestamp() {
    var nowTimestamp = new Date().getTime();
    
    return nowTimestamp;
}

function getDatetime() {
    var nowTimestamp = new Date().getTime();
    var nowDatetime = getYYYYMMddHHmmssSSSWithSymbolCommaUseDate(nowTimestamp);
    
    return nowDatetime;
}

function getDatetimeForResponse() {
    var now = new Date();
    var nowDatetime = getYYYYMMddHHmmssSSSWithSymbolDotUseDate(now);
    
    return nowDatetime;
}

function getYYYYMMddHHmmssSSSWithSymbolCommaUseDate(dateTime) {
    var today = new Date(dateTime);
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second + "," + milliSecond;
}

function getYYYYMMddHHmmssSSSWithSymbolDotUseDate(today) {
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + "T" + hour + ":" + minute + ":" + second + "." + milliSecond;
}

function getTimePatternForService1() {
    var today = new Date();
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());
    var milliSecond = checkLengthDateFormat("" + today.getMilliseconds());
    
    return year + "-" + month + "-" + day + "T" + hour + ":" + minute + ":" + second + "." + milliSecond;
}

function getTimeFormatForDailyReport() {
    var today = new Date();
    var day = checkLengthDateFormat("" + today.getDate());
    var month = checkLengthDateFormat("" + (today.getMonth() + 1));
    var year = checkLengthDateFormat("" + today.getFullYear());
    var hour = checkLengthDateFormat("" + today.getHours());
    var minute = checkLengthDateFormat("" + today.getMinutes());
    var second = checkLengthDateFormat("" + today.getSeconds());

    return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
}

function convertTimeFormatForDailyReport(date) {
    var result = date.replace(/[^0-9]/g,'');

    var yyyy = result.substring(0,4);
    var MM = result.substring(4,6);
    var dd = result.substring(6,8);
    var hh = result.substring(8,10);
    var mm = result.substring(10,12);
    var ss = result.substring(12,14);
    
    return yyyy + "-" + MM + "-" + dd + " " + hh + ":" + mm + ":" + ss;
}

function checkLengthDateFormat(today) {
    if(today.length == 1) {
        today = "0" + today;
    }
    
    return today;
}

function getTargetServer() {
    var path = context.getVariable("proxy.pathsuffix");
    var targetServer = "";
    
    if ((/^(\/users\/.*\/validate)$/).test(path)) {
         targetServer = context.getVariable("userValidateBalEndpoint"); 
    } else if ((/^(\/users\/.*\/refill)$/).test(path)) {
         targetServer = context.getVariable("userRefillEndpoint"); 
    } else if((/^(\/rtr\/.*\/validate)$/).test(path)) {
        targetServer = context.getVariable("rtrValidateEndpoint");  
    } else if((/^(\/rtr\/.*\/refill)$/).test(path)) {
        targetServer = context.getVariable("rtrRefillEndpoint");
    } else if((/^(\/rtr\/.*\/reverse)$/).test(path)) {
        targetServer = context.getVariable("rtrReverseEndpoint");
    } else if((/^(\/rtr\/balance)$/).test(path)) {
        targetServer = context.getVariable("rtrBalanceEndpoint");
    } else if((/^(\/usersRTR\/transaction)$/).test(path)) {
        targetServer = context.getVariable("usersRtrTransactionEndpoint");
    } else if((/^(\/usersRTR\/.*\/refill)$/).test(path)) {
        if(context.getVariable("isServiceCallout")) {
            targetServer = context.getVariable("target.scheme") + "://" + context.getVariable("target.host") + ":" + context.getVariable("target.port") + context.getVariable("usersRtrRefillTransqueryExtPath");
        } else {
            targetServer = context.getVariable("usersRtrRefillEndpoint");
        }
    } 
    
    return targetServer;
}

function setNorthSouthJsonRequestResponse(text) {
    var content = text.replace(/(\r\n|\n|\r)/gm, '');
    var contentRemoveSpace = content.replace(/([^"]+)|""|("[^"]+")/g, function($0, $1, $2) {
        if ($1) {
            return $1.replace(/\s/g, '');      
        } else {
            return $0;   
        }
    });
    
    return contentRemoveSpace;
}

function trimEsbErrorCode(errorCode) {
    
    if (errorCode == null)
        return "";
        
    var trimCode = errorCode;
    
    if(errorCode !== "ESB_14000") {
        trimCode = errorCode.substring(6, errorCode.length);
    }
    
    return trimCode;
}

function trimCbsErrorCode(errorCode) {
    
     if (errorCode == null)
        return "";
        
    var trimCode = errorCode;
    trimCode = errorCode.substring(6, errorCode.length);
    return trimCode;
}

function trimEsbErrorMessage(errorMessage) {
    
     if (errorMessage == null)
        return "";
        
    var index = errorMessage.indexOf(")");
    var trimMessage = errorMessage.substring((index+1), errorMessage.length).trim();
    
    return trimMessage;
}


function setNorthSouthSoapRequestResponse(text) {
    var content = text.replace(/(\r\n|\n|\r)/gm, '');
    var contentRemoveSpace = content.replace(/([>][ ]+[<])/g, function($0, $1, $2) {
        if ($0) {
            return $0.replace(/\s/g, '');      
        } else {
            return $1;   
        } 
    });
    
    return contentRemoveSpace;
}

function setResponse(httpStatusCode, statusCode, statusDesc, statusMsg) {
    var reqType =  context.getVariable("log.reqType");
    
    context.setVariable("resp.httpStatusCode", httpStatusCode);
    context.setVariable("resp.code", statusCode);
    context.setVariable("resp.error", statusDesc);
    context.setVariable("resp.message", statusMsg);
    
    if (reqType == "V") {
        if ((/^(4.*)$/).test(httpStatusCode)) {
            context.setVariable("log.trnsStatus", "I");
        }
        else if ((/^(5.*)$/).test(httpStatusCode)) {
            context.setVariable("log.trnsStatus", "E");
        }
    }
    
    setReasonPhrase(httpStatusCode);
}

function setReasonPhrase(respCode){
    switch(respCode){
        case "200" :
            context.setVariable("resp.reasonPhrase", "OK");
            break;
        case "201" :
            context.setVariable("resp.reasonPhrase", "Created");
            break;
        case "400" :
            context.setVariable("resp.reasonPhrase", "Bad Request");
            break;
        case "403" :
            context.setVariable("resp.reasonPhrase", "Forbidden");
            break;
        case "404" :
            context.setVariable("resp.reasonPhrase", "Resource not found");
            break;
        case "405" :
            context.setVariable("resp.reasonPhrase", "Method Not Allowed");
            break;
        case "429" :
            context.setVariable("resp.reasonPhrase", "Too Many Requests");
            break;
        case "500" :
            context.setVariable("resp.reasonPhrase", "Internal Server Error");
            break;
    }
} 

function genReferenceId(appCode){
    //format: [Application Code]+YYYYMMddHHmmssmsISxxx 
    //ms is mili seconds 3 digits, IS is instance Id 2 digits, xxx is running number 3 digits
    var refId = "";
    var ISxxx = Math.floor(10000 + Math.random() * 9000); // 5 digits
    if(isEmpty(appCode)){
        appCode = "APIGW";
    }
    
    refId = appCode + getYYYYMMddHHmmssSSSWithoutSymbolUseDate(new Date()) + ISxxx;
    return refId;
}

function trimErrorCodeEsb(errorCode) {
    var trimCode = errorCode;
    
    if(errorCode !== "ESB_14000") {
        trimCode = errorCode.substring(6, errorCode.length);
    }
    
    return trimCode;
}

function trimErrorMessageEsb(errorMessage) {
    var index = errorMessage.indexOf(")");
    var trimMessage = errorMessage.substring((index+1), errorMessage.length).trim();
    
    return trimMessage;
}

function trimErrorCodeEsb2(errorMessage) {
    //A function to substring errorCode from errorMessage in format External : (EREFL-2028) Account Not Found
    var indexFirst = errorMessage.indexOf("-") + 1;
    var indexLast = errorMessage.indexOf(")");
    
    return errorMessage.substring(indexFirst, indexLast);
}

function convertTimeFormatForDailyReport(date) {
    var result = date.replace(/[^0-9]/g,'');

    var yyyy = result.substring(0,4);
    var MM = result.substring(4,6);
    var dd = result.substring(6,8);
    var hh = result.substring(8,10);
    var mm = result.substring(10,12);
    var ss = result.substring(12,14);
    
    return yyyy + "-" + MM + "-" + dd + " " + hh + ":" + mm + ":" + ss;
}

function convertDateInFormatForDailyReport(date) {
    //convert to yyyy-mm-dd 00:00:00
    var result = date.replace(/[^0-9]/g,'');

    var yyyy = result.substring(0,4);
    var MM = result.substring(4,6);
    var dd = result.substring(6,8);
    var hh = "00";
    var mm = "00";
    var ss = "00";
    
    return yyyy + "-" + MM + "-" + dd + " " + hh + ":" + mm + ":" + ss;
}
