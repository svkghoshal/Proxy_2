var path = context.getVariable("proxy.pathsuffix");
var statusCode = context.getVariable("resp.status");
var errorMessage = context.getVariable("resp.errorMessage");
var errorCode = context.getVariable("resp.errorCode");

var requestContent = context.getVariable("request.content");
var responseContent = context.getVariable("response.content");


context.setVariable("resp.responseDttm", getDatetimeForResponse());
context.setVariable("southbound.responsedatetime", getTimestamp());
context.setVariable("southboundResponseDatetime", "" + getDatetime());
context.setVariable("southbound.request", setNorthSouthJsonRequestResponse(requestContent));
context.setVariable("southbound.response", setNorthSouthJsonRequestResponse(responseContent));
context.setVariable("southbound.target.server", getTargetServer());
context.setVariable("request.verb", "GET");


print("southbound.target.server : " + context.getVariable("southbound.target.server"));

printTargetResponse(responseContent);

function checkLengthArray (arrayList) {
    if(isEmpty(arrayList.length)) {
        var array_item = [];
        array_item[0] = arrayList;
        arrayList = array_item;   
    }
    
    return arrayList;
}



if (statusCode === "0") {
    var bilMainBal = context.getVariable("resp.BILMainBal");
    var validateAmt = parseFloat(context.getVariable("validateAmount"));
    var topupLimitMax = parseFloat(context.getVariable("refillTopupLimitMax"));
    var subscriberState = context.getVariable("resp.subscriberState");
    var mainBalance = parseFloat(bilMainBal);
    var accountType = "";
    
    var balanceInfoList = [];
        if(!isEmpty(context.getVariable("resp.accountTypeList"))) {
            balanceInfoList = checkLengthArray(JSON.parse(context.getVariable("resp.accountTypeList")));
        }
     
        for(index = 0; index < balanceInfoList.length ; index++){
                accountType = balanceInfoList[index].accountType;
                    if(accountType == 2000){
                        context.setVariable("prepaidFlag", "Y");
                         break;
                    }
        }
            print("prepaidFlag : " + context.getVariable("prepaidFlag") );
            //check accoutType
            if(context.getVariable("prepaidFlag") == "Y"){
                if(subscriberState == "0" || subscriberState == "4"){
                    errorValidateTopupResultMapping("10", "");
                }else{
                    var totalAmt = (parseFloat(bilMainBal/10000) + validateAmt);
                    context.setVariable("bilMainBal", bilMainBal);
                    context.setVariable("totalAmt", totalAmt);
                    if (totalAmt > topupLimitMax) {
                        errorValidateTopupResultMapping("2", "");
                    }else {
                        setResponse("200", "200", "", "");
                    }
                }
            }else{
                errorValidateTopupResultMapping("5", "");
            } 

}else{
    errorValidateTopupResultMapping(errorCode, errorMessage);
}

setReasonPhrase(context.getVariable("resp.code"));