 var payload = context.getVariable("res.activations");
 
 if(!payload)
    context.setVariable("res.activations", "[]");
 else
 {
    var jsonResponse = String(payload).replace(/~STR~/g, "").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
    context.setVariable("res.activations",jsonResponse);
 }
 