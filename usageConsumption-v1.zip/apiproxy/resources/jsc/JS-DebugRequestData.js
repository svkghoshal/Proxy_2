context.setVariable("southboundEndpointUrlDatetime", "" + getDatetime());
context.setVariable("southboundRequestDatetime", "" + getDatetime());

context.setVariable("southbound.requestdatetime", getTimestamp());