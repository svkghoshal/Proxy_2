var CDSSummaryList = context.getVariable("res.CDSSummaryList");
var CDSDetailList = context.getVariable("res.CDSDetailList");

if (!CDSSummaryList)
	context.setVariable("res.CDSSummaryList", "[]");
else {
	var jsonResponse = String(CDSSummaryList).replace(/~STR~/g, "").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
	context.setVariable("res.CDSSummaryList", jsonResponse);
}

if (!CDSDetailList)
	context.setVariable("res.CDSDetailList", "[]");
else {
	var jsonResponse = String(CDSDetailList).replace(/~STR~/g, "").replace(/"~ARRAY~",/g, "").replace(/"~ARRAY~"/g, "");
	context.setVariable("res.CDSDetailList", jsonResponse);
}