 var activationId=context.setVariable("activationId",res);

 
 function randomString(length, chars) {
    var result = '';
    for (var i = length; i > 0; --i) 
    result += chars[Math.round(Math.random() * (chars.length - 1))];
    return result;
}
var res=(randomString(10, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')+transactionDate());
//document.write(res);

function transactionDate() {
	var now = new Date(),
	pad = function (num) {
		var norm = Math.abs(Math.floor(num));
		return (norm < 10 ? '0' : '') + norm;
	};
	return now.getFullYear()
	 + pad(now.getMonth() + 1)
	 + pad(now.getDate());

}
