
print("response.content"+response.content);

var accessTokenInfo = JSON.parse(context.getVariable("response.content"));
print("accessTokenInfo::"+accessTokenInfo);
var clientIDList = context.getVariable("kvm.clientid");
var clientIDArray = "";
var userid= accessTokenInfo.userid;
context.setVariable("userid",userid);
print("accessTokenInfo.clientid :: "+accessTokenInfo.clientid);

if(clientIDList!==null)
    clientIDArray = clientIDList.split(",");

// Calculate TTL
var ttl = accessTokenInfo.ttl > 5*60 ? accessTokenInfo.ttl-1 : 5*60;


if(clientIDArray.indexOf(accessTokenInfo.clientid.toString()) > -1) 
    context.setVariable( "res.access_token-cache-ttl", Math.round( ttl ).toString() );

else {
    var json = {};
	json.error = "invalid_client_id";
	json.error_description = "The client_id from access_token is not authorized";
    context.setVariable("response.status.code", 401);
    context.setVariable("response.content", JSON.stringify(json));
}