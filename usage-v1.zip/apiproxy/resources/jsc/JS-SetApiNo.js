var apiNo;
var proxypath = context.getVariable('proxy.pathsuffix');
var reqVerb = context.getVariable("request.verb");
context.setVariable("reqVerb",reqVerb);

if(proxypath.match('/summary') && (reqVerb.equals("GET")))
	context.setVariable("apiNo","025");
else
    if(proxypath.match('/detail') && (reqVerb.equals("GET")))
        context.setVariable("apiNo","026"); 