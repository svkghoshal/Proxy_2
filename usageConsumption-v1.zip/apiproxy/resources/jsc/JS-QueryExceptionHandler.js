function errorTopupResultMapping(errorCode, errorDesc) {
    switch(errorCode){
        case "4528":
            setResponse("400", "400.043.0004", "Bad Request", errorDesc);
            break;
        case "4572":
            setResponse("400", "400.043.0005", "Bad Request", errorDesc);
            break;
        case "5003":
            setResponse("400", "400.043.0006", "Bad Request", errorDesc);
            break;
        case "4630":
            setResponse("400", "400.043.0007", "Bad Request", errorDesc);
            break;
        case "4708":
            setResponse("400", "400.043.0008", "Bad Request", errorDesc);
            break;
        case "4998":
            setResponse("400", "400.043.0009", "Bad Request", errorDesc);
            break;
        case "3001":
		case "3002":
		case "3003":
		case "3007":
		case "3008":
		case "3009":
		case "3010":
		case "4001":
		case "4709":
		case "5001":
		case "5004":
		case "5005":
		case "5007":
		case "5008":
            setResponse("400", "400.043.0010", "Bad Request", errorDesc);
            break;
        case "4582":
            setResponse("400", "400.043.0011", "Bad Request", "Invalid parameter amount");
            break;
        case "4622":        
            setResponse("400", "400.043.0012", "Bad Request", "Duplicate Transaction Id");
            break;
        case "5030":        
            setResponse("400", "400.043.0013", "Bad Request", "Subscriber doesn't exist");
            break;
        case "4999":
            setResponse("500", "500.043.1001", "Internal Server Error", "Internal Server Error : System error");
            break;
        case "3004":
		case "3005":
		case "4002":
		case "4003":
		case "5002":
		case "5006":
		case "5012":
            setResponse("500", "500.043.1002", "Internal Server Error", errorDesc);
            break;		
        default:
            setResponse("500", "500.043.0000", "Internal Server Error", "Internal Server Error: {" + errorDesc + "}");
            break;
    }
}

function errorValidateTopupResultMapping(errorCode, errorDesc) {
    switch(errorCode){
        case "2":
            setResponse("400", "400.062.0002", "Bad Request", "Refill amount exceeds max topup rate");
            break;
        case "5":
            setResponse("400", "400.062.0005", "Bad Request", "Subscriber is postpaid");
            break;
        case "10":
            setResponse("400", "400.062.0010", "Bad Request", "The subscriber does not exist or the customer that the subscriber belongs to is being migrated. Please check.");
            break;
        case "3004":
            setResponse("500", "500.062.1001", "Internal Server Error", errorDesc);
            break;
        case "3005":
            setResponse("500", "500.062.1002", "Internal Server Error", errorDesc);
            break;
        case "4002":
            setResponse("500", "500.062.1003", "Internal Server Error", errorDesc);
            break;
        case "4003":
            setResponse("500", "500.062.1004", "Internal Server Error", errorDesc);
            break;
        case "4999":
            setResponse("500", "500.062.1005", "Internal Server Error", errorDesc);
            break;
        case "5002":
            setResponse("500", "500.062.1006", "Internal Server Error", errorDesc);
            break;
        case "5006":
            setResponse("500", "500.062.1007", "Internal Server Error", errorDesc);
            break;
        case "5012":
            setResponse("500", "500.062.1008", "Internal Server Error", errorDesc);
            break;       
        case "5003":
            setResponse("400", "400.062.0003", "Bad Request", errorDesc);
            break;
        case "5011":
            setResponse("400", "400.062.0004", "Bad Request", errorDesc);
            break;        
        case "5013":
            setResponse("400", "400.062.0006", "Bad Request", errorDesc);
            break;
        case "4708":
            setResponse("400", "400.062.0007", "Bad Request", errorDesc);
            break;
        case "4709":
            setResponse("400", "400.062.0008", "Bad Request", errorDesc);
            break;
        case "3001":
		case "3003":
		case "3007":
		case "3008":
		case "3009":
		case "3010":
		case "4001":
		case "4528":
		case "4572":
		case "4998":
		case "4630":
		case "4582":
		case "5001":
		case "5004":
		case "5005":
		case "5007":
		case "5008":
		case "5009":
		case "5010":
		case "5014":
		case "5015":
		case "5016":
		case "5017":
            setResponse("400", "400.062.0009", "Bad Request", errorDesc);
            break;
        case "3002":
		case "5030":
            setResponse("400", "400.062.0010", "Bad Request", "The subscriber does not exist or the customer that the subscriber belongs to is being migrated. Please check.");
            break;        
        default:
            setResponse("500", "500.062.0000", "Internal Server Error", "Internal Server Error: {" + errorDesc + "}");
            break;
    }
}

function errorRtrValidateResultMapping(errorCode) {
    switch(errorCode){
        case "2028":
        case "2045":
			setResponse("400", "400.064.0003", "Bad Request", "Agent not registered.");
			break;
		case "2065":
			setResponse("400", "400.064.0004", "Bad Request", "Password is invalid.");
			break;
		case "902":
			setResponse("500", "500.064.1002", "Internal Server Error", "Unexpected system error occurred.");
			break;
		case "303":
			setResponse("500", "500.064.1006", "Internal Server Error", "Access to the function is forbidden.");
			break;
        default:
            setResponse("500", "500.064.0000", "Internal Server Error", "Internal Server Error");
            break;
    }
}

function errorRtrRefillResultMapping(errorCode) {
    switch(errorCode){
        case "2028":
        case "2045":
			setResponse("400", "400.065.0002", "Bad Request", "Initiator is not registered.");
			break;
		case "2031":
			setResponse("400", "400.065.0003", "Bad Request", "Initiator is inactive.");
			break;
		case "2029":
			setResponse("400", "400.065.0004", "Bad Request", "Initiator is suspended.");
			break;
		case "2015":
			setResponse("400", "400.065.0009", "Bad Request", "Initiator is stopped.");
			break;
		case "2065":
			setResponse("400", "400.065.0010", "Bad Request", "Password is invalid.");
			break;
		case "42":
			setResponse("400", "400.065.0015", "Bad Request", "Amount out of range ");
			break;
		case "1000":
			setResponse("400", "400.065.0018", "Bad Request", "Debtor wallet has insufficient funds.");
			break;
		case "2067":
		case "2080":
			setResponse("400", "400.065.0020", "Bad Request", "Wallet balance exceeds cap limit.");
			break;
		case "902":
			setResponse("500", "500.065.1002", "Internal Server Error", "Unexpected system error occurred.");
			break;
		case "303":
			setResponse("500", "500.065.1004", "Internal Server Error", "Access to the function is forbidden.");
			break;
        default:
            setResponse("500", "500.065.0000", "Internal Server Error", "Internal Server Error");
            break;
    }
}

function errorRtrReverseResultMapping(errorCode) {
    switch(errorCode){
        case "2028":
        case "2045":
			setResponse("400", "400.066.0002", "Bad Request", "Initiator is not registered.");
			break;
		case "2031":
			setResponse("400", "400.066.0003", "Bad Request", "Initiator is inactive.");
			break;
		case "2029":
			setResponse("400", "400.066.0004", "Bad Request", "Initiator is suspended.");
			break;
		case "2015":
			setResponse("400", "400.066.0009", "Bad Request", "Initiator is stopped.");
			break;
		case "2065":
			setResponse("400", "400.066.0010", "Bad Request", "Password is invalid.");
			break;
		case "42":
			setResponse("400", "400.066.0015", "Bad Request", "Amount out of range ");
			break;
		case "1000":
			setResponse("400", "400.066.0018", "Bad Request", "Debtor wallet has insufficient funds.");
			break;
		case "2067":
			setResponse("400", "400.066.0020", "Bad Request", "Wallet balance exceeds cap limit.");
			break;
		case "92":
		case "3074":
		case "2069":
			setResponse("400", "400.066.0023", "Bad Request", "Transaction does not exist or the transaction has already been reversed.");
			break;
		case "902":
			setResponse("500", "500.066.1002", "Internal Server Error", "Unexpected system error occurred.");
			break;
		case "303":
			setResponse("500", "500.066.1004", "Internal Server Error", "Access to the function is forbidden.");
			break;
        default:
            setResponse("500", "500.066.0000", "Internal Server Error", "Internal Server Error");
            break;
    }
}

function errorUserRtrRefillResultMapping(errorCode) {
    switch(errorCode){
        case "2065":
        case "402":
        case "404":
			setResponse("400", "400.006.0005", "Bad Request", "Invalid PIN");
			break;
		case "1000":
			setResponse("400", "400.006.0007", "Bad Request", "Insufficient funds on reseller account");
			break;
		case "2067":
			setResponse("400", "400.006.0008", "Bad Request", "Exceed RTR Balance");
			break;
		case "3125":
		case "3126":
        case "3127":
        case "3128":
        case "3132":
        case "3133":
        case "3134":
        case "3138":
        case "3141":
        case "3153":
        case "3156":
        	setResponse("400", "400.006.0011", "Bad Request", "Invalid Recived Number");
        	break;
        case "42":
        case "3129":
        	setResponse("400", "400.006.0012", "Bad Request", "Invalid Amount");
        	break;
		case "304":
        case "2015":
        case "2024":
        case "2025":
        case "2026":
        case "2027":
        case "2028":
        case "2029":
        case "2030":
        case "2031":
        case "2032":
        case "2040":
        case "2041":
        case "2044":
        case "2045":
        case "2075":
        case "2076":
			setResponse("400", "400.006.0013", "Bad Request", "Invalid RTR number");
			break;
		case "902":
		case "303":
			setResponse("500", "500.006.1002", "Internal Server Error", "Backend Error");
			break;
        default:
            setResponse("500", "500.006.0000", "Internal Server Error", "Internal Server Error");
            break;
    }
}

function errorRtrBalanceResultMapping(errorCode){
    switch(errorCode){
        case "2028":
        case "2045":
			setResponse("400", "400.067.0002", "Bad Request", "Initiator is not registered.");
			break;
		case "2031":
			setResponse("400", "400.067.0003", "Bad Request", "Initiator is inactive.");
			break;
		case "2029":
			setResponse("400", "400.067.0004", "Bad Request", "Initiator is suspended.");
			break;
		case "2015":
			setResponse("400", "400.067.0009", "Bad Request", "Initiator is stopped.");
			break;
		case "2065":
			setResponse("400", "400.067.0010", "Bad Request", "Password is invalid.");
			break;
		case "902":
			setResponse("500", "500.067.1002", "Internal Server Error", "Unexpected system error occurred.");
			break;
		case "303":
			setResponse("500", "500.067.1004", "Internal Server Error", "Access to the function is forbidden.");
			break;
        default:
            setResponse("500", "500.067.0000", "Internal Server Error", "Internal Server Error");
            break;
    }
}

function errorUsersRtrTransactionResultMapping(errorCode) {
    switch(errorCode){
        case "92":
			setResponse("400", "400.068.0001", "Bad Request", "The transaction ID provided in the request does not exist.");
			break;
		case "2028":
		case "2045":
			setResponse("400", "400.068.0002", "Bad Request", "Initiator is not registered.");
			break;
		case "2065":
			setResponse("400", "400.068.0003", "Bad Request", "Password is invalid.");
			break;
		case "902":
			setResponse("500", "500.068.1002", "Internal Server Error", "Unexpected system error occurred.");
			break;
		case "303":
			setResponse("500", "500.068.1004", "Internal Server Error", "Access to the function is forbidden.");
			break;
        default:
            setResponse("500", "500.068.0000", "Internal Server Error", "Internal Server Error");
            break;
    }
}