context.setVariable("cusAttr.developerApp", context.getVariable("app.DisplayName")); 
 