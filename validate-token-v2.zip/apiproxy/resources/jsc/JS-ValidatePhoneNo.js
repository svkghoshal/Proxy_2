var accessTokenInfo = JSON.parse( context.getVariable( "response.content" ) );
var phoneNoInfo = JSON.parse(context.getVariable( "phonecalloutResponse.content" ) );
var telenorList = context.getVariable("kvm.telenorno");
var telenorNoArray = [];
var idValue = context.getVariable("req.idValue");
var msisdn;
var ttl = accessTokenInfo.ttl > 5*60 ? accessTokenInfo.ttl-1 : 5*60;

if(telenorList.length!==null)
    telenorNoArray = telenorList.split(","); //KVM values(telenorno) inserting in array
    context.setVariable("telenorNoArray[]",telenorNoArray.toString());

var phoneNo = [];
for(i=0;i< phoneNoInfo.phone.length;i++) //phone numbers from phone API inserted into array
{
//x+= myObj.phone[i].number;
    phoneNo[i]=tempMsisdn(phoneNoInfo.phone[i].number);
}
context.setVariable("phoneNo[]",phoneNo.toString());

if(phoneNo.indexOf(tempMsisdn(idValue).toString()) > -1) //to check request idValue of URL exists in Phone no array
{
    
    if(telenorNoArray.indexOf(tempMsisdn(idValue).substring(0, 3)) > -1) //to check idValue is telenor no or not
        context.setVariable( "res.access_token-cache-ttl", Math.round( ttl ).toString() ); //returm access token
    else {
        var json = {};
    	json.error = "invalid phone no";
    	json.error_description = "MSISDN is non telenor no";
        context.setVariable("response.status.code", 401);
        context.setVariable("response.content", JSON.stringify(json));
        }
}
else
{
        var json = {};
    	json.error = "invalid Phone no";
    	json.error_description = "Phone no does not exists";
        context.setVariable("response.status.code", 401);
        context.setVariable("response.content", JSON.stringify(json));
}

function tempMsisdn(tempmsisdn)
{
    if(tempmsisdn.length>10)
    {
     msisdn=tempmsisdn.substring(tempmsisdn.length-10, tempmsisdn.length);
     return msisdn;
    }
    else
    return tempmsisdn;
}