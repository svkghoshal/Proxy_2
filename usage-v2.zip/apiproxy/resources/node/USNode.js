 http = require('http');
 var apigee = require('apigee-access');

server= http.createServer( function(req, res) 
{
console.log ('user'+req);
console.log ('Request ::: '+JSON.stringify(req.Body));
var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
console.log('proxypath : '+proxypath);
var reqVerb = apigee.getVariable(req,'request.verb');
console.log('requestVerb : '+reqVerb);

var bodyUS ="<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
                "<S:Body>" +
                    "<ns3:GetCDRSummaryResponse xmlns:ns3=\"http://webservice.cdsviewsummary.wipro.com/\" xmlns:ns2=\"http://telenor.com.mm//input\">" +
                        "<return>" +
                            "<CDSSummaryList>" +
                                "<charges>0</charges>" +
                                "<serviceType>DATA</serviceType>" +
                            "</CDSSummaryList>" +
                            "<status>Success</status>" +
                        "</return>" +
                    "</ns3:GetCDRSummaryResponse>" +
                "</S:Body>" +
            "</S:Envelope>";
            
var bodyUD= "<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
                "<S:Body>" +
                    "<ns3:GetCDRSummaryResponse xmlns:ns3=\"http://webservice.cdsviewsummary.wipro.com/\" xmlns:ns2=\"http://telenor.com.mm//input\">" +
                        "<return>" +
                            "<CDSSummaryList>" +
                                "<charges>0</charges>" +
                                "<serviceType>DATA</serviceType>" +
                            "</CDSSummaryList>" +
                            "<status>Success</status>" +
                        "</return>" +
                    "</ns3:GetCDRSummaryResponse>" +
                "</S:Body>" +
            "</S:Envelope>";

res.writeHead(200, {'Content-Type': 'application/xop+xml'});
 
 var body = "";

if(proxypath.match('/summary'))
    body = bodyUS;
else if (proxypath.match('/detail/*'))
     body = bodyUD;
else
    console.log('NO TARGET selected');

    
res.end(body);

});


port = 3000;

host = '127.0.0.1';

server.listen(port, host);

console.log ('Listening at http://' + host + ':' + port); 