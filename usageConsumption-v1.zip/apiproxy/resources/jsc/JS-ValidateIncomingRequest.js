var path = context.getVariable("proxy.pathsuffix");
var verb = context.getVariable("request.verb");

context.setVariable("northboundRequestDatetime", "" + getDatetime());
context.setVariable("log.requestDateTime", "" + getTimeFormatForDailyReport());

context.setVariable("southbound.requestdatetime", getTimestamp());

context.setVariable("req.sentDttm", getDatetimeForResponse());

context.setVariable("isCompanyProvided", true);

switch(verb) {
    case "GET":
        context.setVariable("northbound.request", context.getVariable('request.querystring'));
        
        if((/^(\/rtr\/.*\/validate)$/).test(path)) {
            context.setVariable("proxyPathSuffix", "/rtr/*/validate");
            context.setVariable("suffixPath", "RtrValidate");
            validateRtrValidate();
        }
        break;
    default:
        context.setVariable("validateError", "ResourceNotFound");
        break;
}
context.setVariable("responseDatetime", getDatetime());
context.setVariable("resp.responseDttm", getDatetimeForResponse());

function validateRtrValidate() {
    var urlId = context.getVariable("req.urlId");
    var transactionId = context.getVariable("req.transactionId");
    var validateAmount = context.getVariable("req.validateAmount");
    var partnerRetailerNumber = context.getVariable("req.partnerRetailerNumber");
    var partnerPartnerCode = context.getVariable("req.partnerPartnerCode");
    var isEnableHttps = context.getVariable("rtrValidateIsEnableHttps");
    
    print("validateRtrValidate:param(mandatory):"
        + ", urlId = " + urlId
        + ", validate.txid = " + transactionId
        + ", validate.amount = " + validateAmount
        + ", partner.retailerNumber = " + partnerRetailerNumber
        + ", partner.partnerCode = " + partnerPartnerCode);

    if(isEmpty(transactionId) || isEmpty(validateAmount) || isEmpty(partnerRetailerNumber) ||
       isEmpty(partnerPartnerCode) ) {
        context.setVariable("validateError", "BusinessValidationFailed");
    }
    if(isNotSameIdAndNumber(urlId, partnerRetailerNumber)) {
        context.setVariable("validateError", "BusinessValidationFailed");
    }
    
    context.setVariable("transactionId", transactionId);
    context.setVariable("isEnableHttps", isEnableHttps);
    context.setVariable("referenceId", genReferenceId(context.getVariable("sourceSystemId")));
}


function isNotSameIdAndNumber(urlId, retailerNumber) {
    if(urlId != retailerNumber) {
        return true;
    } else {
        return false;
    }
}