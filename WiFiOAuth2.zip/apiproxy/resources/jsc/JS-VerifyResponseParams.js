var token_type = context.getVariable("res.token_type");
var expires_in = context.getVariable("res.expires_in");
//context.setVariable("transactionId",transactionId);
var status_code=0;
var access_token = context.getVariable("res.access_token");

var error=context.getVariable("res.error");
var message=context.getVariable("res.message");
/*context.setVariable("error",error);
context.setVariable("mesge",message);*/

if (access_token !== null)
{
    context.setVariable("token_type",token_type);
    context.setVariable("expires_in",expires_in);
    context.setVariable("access_token",access_token);
    context.setVariable("status_code","200");
}

else
{
    
    context.setVariable("exceptionName", "exceptionName");
	context.setVariable("errorCode", "500." + apiNo + ".100");
	context.setVariable("errorDesc", "Internal Server Error");
	context.setVariable("errorMessage",message);
	context.setVariable("httpError", "500");
}






